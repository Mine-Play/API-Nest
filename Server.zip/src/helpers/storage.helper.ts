// import { S3Client, ListBucketsCommand } from "@aws-sdk/client-s3";

// export class Storage {
//     client;

//     constructor(){

//     }
// }