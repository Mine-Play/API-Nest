export class Avatar {
    static classic(uri: string): string{
        return "ASAP";
    }
}