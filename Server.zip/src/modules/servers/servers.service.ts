import { Injectable } from '@nestjs/common';

@Injectable()
export class ServersService {
    //constructor(@InjectRepository(Sessions) private sessionRepository: Repository<Sessions>) {}
}
