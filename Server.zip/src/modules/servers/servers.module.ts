import { Module } from '@nestjs/common';
import { ServersService } from './servers.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Server } from './servers.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([ Server ]),
  ],
  providers: [ServersService],
  controllers: [],
  exports: [ServersService],
})
export class ServersModule {}