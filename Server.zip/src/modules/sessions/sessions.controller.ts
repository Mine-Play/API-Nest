import { Controller } from '@nestjs/common';

@Controller('sessions')
export class SessionsController {

}