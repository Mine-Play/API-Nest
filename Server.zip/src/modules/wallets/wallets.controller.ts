import { Controller } from '@nestjs/common';

@Controller('wallet')
export class WalletController {}
