export interface Texture {
    url:  string | boolean;
    type?: string | boolean;
}